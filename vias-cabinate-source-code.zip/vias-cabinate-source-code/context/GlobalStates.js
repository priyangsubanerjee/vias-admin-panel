const { createContext } = require("react");

const GlobalState = createContext(null);

export default GlobalState;
